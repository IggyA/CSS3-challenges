# Challenge: sidebar

Add CSS styles for `sidebar.html` so it appears in the browser with the following design.  
_Note: add proper classes to the HTML if needed_  
_Hint: styles for `html` , `body`, `h1`, `h2`, `.sidebar`, `.sidebar h2`_ should be enough


![result](img/result.png)

